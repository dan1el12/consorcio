<?php
    class ProveedorModel
    {
        private $pdo;
        public function __CONSTRUCT()
        {
            try 
            {
                $this->pdo = new PDO('mysql:host=localhost;dbname=consorcio','root','');
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
            }
            catch(Exception $e)
            {
                die($e->getMessage());
            }
        }
        public function Listar(){
            try
            {

              $result = array();
              $stm = $this->pdo->prepare("SELECT * FROM proveedor");
              $stm->execute();
              foreach($stm->fetchAll(PDO::FETCH_OBJ) as $r)
                {
                  $alm = new proveedor();
                  $alm->__SET('id', $r->id);
                  $alm->__SET('nom', $r->nom);
                  $alm->__SET('telef', $r->telef);
                  $alm->__SET('email', $r->email);
                  $alm->__SET('direc', $r->direc);
                  $alm->__SET('repr', $r->repr);
                  $alm->__SET('ruc', $r->ruc);
                  $alm->__SET('rub', $r->rub);
                  
                  $result[] = $alm;
                }
                return $result;
            }
            catch(Exception $e)
            {
              die($e->getMessage());
            }
        }
        public function Obtener($id)
        {
            try
            {
                $stm = $this->pdo
                ->prepare("SELECT * FROM proveedor WHERE id = ?");
                $stm->execute(array($id));
                $r = $stm->fetch(PDO::FETCH_OBJ);
                $alm = new proveedor();
                $alm->__SET('id', $r->id);
                $alm->__SET('nom', $r->nom);
                $alm->__SET('telef', $r->telef);
                $alm->__SET('email', $r->email);
                $alm->__SET('direc', $r->direc);
                $alm->__SET('repr', $r->repr);
                $alm->__SET('ruc', $r->ruc);
                $alm->__SET('rub', $r->rub);
                return $alm;
            } 
            catch (Exception $e)
            {
                die($e->getMessage());
            }   
        }
        public function Eliminar($id)
        {
            try
            {
                $stm = $this->pdo
                ->prepare("DELETE FROM proveedor WHERE id = ?");
                $stm->execute(array($id));
            } 
            catch (Exception $e)
            {
                die($e->getMessage());
            }
        }
        public function Actualizar(proveedor $data)
        {
            try
            {

                $sql = "UPDATE proveedor SET
                nom = ?,
                telef = ?,
                email = ?,
                direc = ?,
                repr = ?,
                ruc = ?,
                rub = ?
                WHERE id = ?";
                $this->pdo->prepare($sql)
                ->execute(
                array(
                $data->__GET('nom'),
                $data->__GET('telef'),
                $data->__GET('email'),                
                $data->__GET('direc'),
                $data->__GET('repr'),
                $data->__GET('ruc'),
                $data->__GET('rub'),
                $data->__GET('id')
                )
                );
            } 
            catch (Exception $e)
            {
                die($e->getMessage());
            }
        }

        public function Registrar(proveedor $data)
        {
            try
            {
                $sql = "INSERT INTO proveedor (nom,telef,email,direc,repr,ruc,rub) VALUES ( ?, ?, ?,?,?,?,?)";
                $this->pdo->prepare($sql)->execute(array(
                $data->__GET('nom'),
                $data->__GET('telef'),
                $data->__GET('email'),
                $data->__GET('direc'),
                $data->__GET('repr'),
                $data->__GET('ruc'),
                $data->__GET('rub'),
                )
                );
            }   
            catch (Exception $e)
            {
                die($e->getMessage());
            }
        }
    }   
?>