<?php
    class Proveedor
    {
        private $id;
        private $nom;
        private $telef;
        private $email;
        private $direc;
        private $repr;
        private $ruc;
        private $rub;
        
        public function __GET($k){
            return $this->$k;
        }
        public function __SET($k,$v){
            return $this->$k = $v;
        }
    }
?>