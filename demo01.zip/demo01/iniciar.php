<?php
	// Sesion
	session_start();
	// Invocando al archivo serv.php
	include ('serv.php');
	// Se encontró una sesión en la ventana actual
	if (isset($_SESSION['user'])){
		// Abrir el panel.php
		echo '<script>window.location="panel.php"; </script>';
	}
?>

<!DOCTYPE HTML>
<html>
	<head>
		<title>SIATMEDIA</title>

		<meta charset="utf-8" />

		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<link rel="stylesheet" href="css/bootstrap.min.css" />

		<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
			
            <div class="container">
            	<div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <img src="img/siatmedia_logo.png" 
								class="img-responsive img-fluid" 
								alt="Siatmedia">
						<h2 class="text-center">Aplicacion Consorcio</h2>
						<h3 class="text-center">Exclusivo para Senati</h3>
						<p class="text-center">Ingrese a la plataforma de negocios</p>
					</div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        
                    </div>
                    <div class="col-md-4">
                        <h3><center>INICIAR SESIÓN</center></h3>
				        <br>
						<!-- Formular metodo post y se dirige a validar.php-->
				        <form method="post" action="validar.php">
							<!-- Div agrupar elementos de formulario -->
                            <div class="form-group">
				            <input 
								type="text" 
								name="usuario" 
								value="" 
								placeholder="Usuario" 
								class="form-control"/><br>
				            <input 
								type="password" 
								name="clave" 
								value="" 
								placeholder="Password" 
								class="form-control"/><br>
				            <footer>
				                <input 
									type="submit" 
									value="Ingresar" 
									name="login"
									class="btn btn-primary btn-block" />
				                <a href="#" 
									class="btn btn-success btn-block">
									Regresar
								</a>
								<a href="registrar.php" 
									class="btn btn-info btn-block">
									Crear Cuenta
								</a>						
				            </footer>
				            </div>
						</form>
					</div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>			
		
	</body>
</html>
